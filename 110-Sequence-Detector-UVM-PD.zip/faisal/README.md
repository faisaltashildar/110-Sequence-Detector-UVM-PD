# 110-Sequence-Detector-UVM-PD
A 110 sequence detector implemented using Verilog and SystemVerilog with UVM for verification. Includes physical design (RTL to GDSII) for ASIC/FPGA implementation. The project covers design, verification, and synthesis, ensuring optimized and robust detection.
